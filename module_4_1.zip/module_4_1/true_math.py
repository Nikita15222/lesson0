from math import inf
def true_divide(a, b):
    if b == 0:
        return inf
    else:
        result = a/b
    return result