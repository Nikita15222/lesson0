def fake_divide(a, b):
    if b == 0:
        result = "Ошибка"
    else:
        result = a/b
    return result